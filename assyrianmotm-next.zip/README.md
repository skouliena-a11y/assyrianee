# assyrianMOTM — Next.js Site

A sleek, sponsor-ready site built with Next.js 14, Tailwind, framer-motion, and lucide-react.

## Local dev
```bash
npm install
npm run dev
```

## Deploy to Vercel
1. Create a new GitHub repository and upload these files.
2. Go to https://vercel.com/new and **Import** the repo.
3. Accept defaults and click **Deploy**.
4. Done — you'll get a public URL like `https://assyrianmotm.vercel.app`.

No environment variables are required.
