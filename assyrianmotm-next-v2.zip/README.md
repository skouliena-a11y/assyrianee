# assyrianMOTM — Next.js site

## Local
npm install
npm run dev

## Deploy (Vercel)
- Push to GitHub, then Import Project in Vercel.
- No env vars needed.
